## Hi there 👋

<!--
**hasmattechuz/hasmattechuz** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.
  
#Server URL
https://techuz-html.netlify.app/

#CodePen URL
#For Slider Code
https://codepen.io/mahi72099/pen/vEBqvzg

#For runinng SCSS
source $(brew --prefix nvm)/nvm.sh 
npm install -g sass
sass --watch assets/scss/style.scss assets/css/style.css
-->
